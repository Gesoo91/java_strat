package com.kdj.board.data;

import java.util.ArrayList;

public class DataBox {
	static public ArrayList<Data> list = new ArrayList<>();
//	static public void loadData() {
//		list = new ArrayList<>(); // 객체초기화를 해줬으나 loadData를 실행하지 않았기 때문에 nullPointerException 오류가 일어났다.
//	}
	
		
	}

